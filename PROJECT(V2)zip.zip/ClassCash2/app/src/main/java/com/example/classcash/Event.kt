package com.example.classcash

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun Event() {
    val currentDate = remember { LocalDate.now() }
    val events = remember { mutableStateOf(mapOf<LocalDate, String>()) } // Placeholder for events


    Column(modifier = Modifier
        .fillMaxHeight()
        .background(Color(0xFFADEBB3))
    ) {

        //TopScreen
        TopScreenB()

        Spacer(modifier = Modifier.height(10.dp))

        // Calendar
        CalendarView(currentDate, events)

        Spacer(modifier = Modifier.height(50.dp))

        // Event Views
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .verticalScroll(rememberScrollState()), // Vertical scroll on Column
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            repeat(3) {
                EventBox()
            }
        }

    }
}


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun CalendarView(
    currentDate: LocalDate,
    events: MutableState<Map<LocalDate, String>>
) {
    val daysInMonth = currentDate.lengthOfMonth()
    val firstDayOfMonth = currentDate.withDayOfMonth(1)
    val firstDayOffset = (firstDayOfMonth.dayOfWeek.value % 7) // Shift to start on Sunday

    val calendarDays = buildList {
        repeat(firstDayOffset) { add(null) } // Empty boxes before the first day
        addAll((1..daysInMonth).map { day -> LocalDate.of(currentDate.year, currentDate.month, day) })
    }

    val daysOfWeek = listOf(
        DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
        DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(16.dp)
    ) {
        // Display month and year
        Text(
            text = "${currentDate.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${currentDate.year}",
            fontSize = 20.sp,
            color = Color.Blue,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Display day of the week headers (starting Sunday)
        Row(modifier = Modifier.fillMaxWidth()) {
            daysOfWeek.forEach { day ->
                Text(
                    text = day.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                    fontSize = 16.sp,
                    modifier = Modifier
                        .weight(1f)
                        .padding(4.dp),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Display calendar days
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            content = {
                items(calendarDays) { date ->
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(if (date != null && events.value.containsKey(date)) Color.Red else Color.Transparent)
                            .border(1.dp, Color.Black)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = date?.dayOfMonth?.toString() ?: "")
                    }
                }
            }
        )
    }
}



@Composable
fun EventBox() {
    var eventName by remember { mutableStateOf("") }
    Box(
        modifier = Modifier
            .height(90.dp)
            .padding(8.dp)
            .border(BorderStroke(1.dp, Color.Blue), RoundedCornerShape(12.dp))
            .background(Color.White, RoundedCornerShape(10.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = R.drawable.circle_add),
                contentDescription = "Add Event",
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            TextField(
                value = eventName,
                onValueChange = { eventName = it },
                placeholder = {
                    Text("Add Event",
                        color = Color.Gray.copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    ) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black
                ),
                modifier = Modifier.width(200.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                painter = painterResource(id = R.drawable.generate_budget),
                contentDescription = "Generate Budget",
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
