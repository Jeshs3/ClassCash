package com.example.classcash

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState

sealed class BottomNavScreen(val route: String, val label: String, val icon: Int) {
    data object Home : BottomNavScreen(Routes.dashboard, "Dashboard", R.drawable.ic_home)
    data object Event : BottomNavScreen(Routes.event, "Event", R.drawable.ic_event)
    data object Analytics : BottomNavScreen(Routes.analytics, "Analytics", R.drawable.ic_analytics)
    data object Fund : BottomNavScreen("fund", "Fund", R.drawable.ic_fund)
    data object Recommend : BottomNavScreen("recommend", "Recommend", R.drawable.ic_recommend)
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    val items = listOf(
        BottomNavScreen.Home,
        BottomNavScreen.Event,
        BottomNavScreen.Analytics,
        BottomNavScreen.Fund,
        BottomNavScreen.Recommend
    )

    NavigationBar (
        modifier = Modifier
            .padding(10.dp)
            .padding(start = 8.dp, end = 8.dp)
            .height(80.dp),
        containerColor = Color(0xFFFBFCFE),
        contentColor = Color(0xFFADEBB3),
    ) {
        val navBackStackEntry = navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry.value?.destination?.route

        items.forEach { screen ->
            NavigationBarItem(
                icon = { Icon(painterResource(id = screen.icon), contentDescription = screen.label) },
                selected = currentRoute == screen.route,
                onClick = {
                    if (currentRoute != screen.route) {
                        navController.navigate(screen.route)
                    }
                }
            )
        }
    }
}


