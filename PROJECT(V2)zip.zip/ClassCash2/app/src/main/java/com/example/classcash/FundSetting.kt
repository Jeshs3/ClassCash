package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FundSetting() {
    var duration by remember { mutableStateOf("") }
    var dailyFund by remember { mutableStateOf("") }
    var selectedMonth by remember { mutableStateOf("2024") }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .background(Color(0xFFADEBB3)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        //Top Screen Bar
        TopScreenB()

        // 'Set Collection' label
        Text(
            text = "Set Collection",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        Box(
            modifier = Modifier
                .padding(8.dp)
                .shadow(
                    elevation = 8.dp,        // Adjust shadow elevation
                    shape = RoundedCornerShape(10.dp), // Rounded corners
                    clip = false             // Whether to clip content to the shape
                )
                .background(Color.White)    // White background
                .fillMaxWidth()
                .height(70.dp)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ){
            TextField(
                value = duration,
                onValueChange = {duration = it},
                placeholder = {
                    Text(
                        text = "Enter how many months you need to collect",
                        color = Color.Gray.copy(alpha = 0.5f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent
                )
            )

        }

        Box(
            modifier = Modifier
                .padding(8.dp)
                .shadow(
                    elevation = 8.dp,        // Adjust shadow elevation
                    shape = RoundedCornerShape(10.dp), // Rounded corners
                    clip = false             // Whether to clip content to the shape
                )
                .background(Color.White)    // White background
                .fillMaxWidth()
                .height(70.dp)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ){
            TextField(
                value = dailyFund,
                onValueChange = {dailyFund = it},
                placeholder = {
                    Text(
                        text = "How much is the daily fund each student?",
                        color = Color.Gray.copy(alpha = 0.5f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent
                )
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Main container with dropdown and label
        MonthDropdownContainer(selectedMonth) { month -> selectedMonth = month }
    }
}


@Composable
fun MonthDropdownContainer(selectedMonth: String, onMonthSelected: (String) -> Unit) {
    Column(
        modifier = Modifier
            .padding(start = 10.dp,end = 10.dp)
            .background(Color(0xFFFBFCFE), shape = RoundedCornerShape(8.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Dropdown for choosing month
            MonthDropdown(selectedMonth, onMonthSelected)

            // 'Setup the date' label
            Text(
                text = "Setup the date",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Paginated cards
        CollectionBox()
    }
}

@Composable
fun MonthDropdown(selectedMonth: String, onMonthSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.clickable { expanded = true }) {
        Text(text = selectedMonth)

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            // List of months
            val months = listOf(
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            )

            // Directly adding month selection options
            months.forEach { month ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onMonthSelected(month)
                            expanded = false
                        }
                        .padding(8.dp)
                ) {
                    Text(text = month)
                }
            }
        }
    }
}


@Composable
fun CollectionBox() {
    Column(
        modifier = Modifier
            .padding(16.dp)
            .background(Color.White, shape = RoundedCornerShape(16.dp))
            .padding(vertical = 16.dp, horizontal = 8.dp)
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp),

        ) {
            listOf("August", "September", "October").forEach { month ->
                CollectionMonthItem(monthName = month, amount = "₱0.00")
            }
        }
    }
}

@Composable
fun CollectionMonthItem(monthName: String, amount: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF5F5F5), shape = RoundedCornerShape(8.dp))
            .padding(vertical = 12.dp, horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = monthName,
                fontWeight = FontWeight.Bold)
            Text(text = amount,
                fontWeight = FontWeight.Black,
                color = Color.Blue)
        }
        IconButton(onClick = { /* Handle the click event here */ }) {
            Icon(
                painter = painterResource(id = R.drawable.ic_calendar),
                contentDescription = "Calendar"
            )
        }

    }
}
