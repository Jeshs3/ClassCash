package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

@Composable
fun AddStudentScreen() {

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .background(Color(0xFFADEBB3)) // Mint green background
            .padding(10.dp)
    ) {
        //Top Screen Bar
        TopScreenB()

        // Student Count & Add Student Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("0 Students", style = MaterialTheme.typography.bodyLarge)
            IconButton(onClick = { /* TODO: Add Add Student functionality */ }) {
                // Replace with add icon
                /* Empty Icon */
            }
        }

        // Add Student Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Title Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Add Student", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Automatically saved",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray.copy(alpha = 0.5f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Student Input Fields
                (1..10).forEach { index ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$index.",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        OutlinedTextField(
                            value = "",
                            onValueChange = { /* TODO: Handle input */ },
                            placeholder = {
                                Text(
                                    "Input Student Name",
                                    color = Color.Gray.copy(alpha = 0.5f),
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Center
                                ) },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(50),
                            singleLine = true
                        )
                        IconButton(onClick = { /* TODO: Handle delete */ }) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_close),
                                contentDescription = "Delete Data",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Save Button
                Button(
                    onClick = { /* TODO: Handle Save */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    shape = RoundedCornerShape(50)
                ) {
                    Text("Save", color = Color.White)
                }
            }
        }
    }
}