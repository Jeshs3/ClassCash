package com.example.classcash

object Routes {
    var splashscreen = "splashscreen"
    var login = "login"
    var dashboard = "dashboard"
    var studentadd = "studentadd"
    var event = "event"
    var analytics = "analytics"
    var fund = "fund"
    var recommend = "recommend"
    var trview = "trview"
}