package com.example.classcash

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(navController: NavController) {
    LaunchedEffect(Unit) {
        delay(2000L) // Delay for 2 seconds
        navController.navigate(Routes.login)
    }

    Column(
        modifier = Modifier.fillMaxSize()
            .background(Color(0xFFADEBB3)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
            Image(
                painter = painterResource(id = R.drawable.classlogo),
                contentDescription = "logo"
            )

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "ClassCash",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Make your funds accounted automatically",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraLight
            )


            Spacer(modifier = Modifier.height(40.dp))
            Text(
                text = "LOADING...",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraLight
            )
    }
}
