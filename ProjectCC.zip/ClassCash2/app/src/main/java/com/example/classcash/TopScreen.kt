package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.*
import androidx.compose.ui.Alignment
import kotlinx.coroutines.delay


@Composable
fun TopScreenB() {
    var currentClassName by remember { mutableStateOf("") } // Replace initial value with "" or any default
    var isTyping by remember { mutableStateOf(false) }

    // Trigger the save function after inactivity
    LaunchedEffect(currentClassName) {
        isTyping = true
        delay(500) // Wait for 500ms of inactivity
        isTyping = false
        // Replace onSaveClassName logic with your save function here
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp)
            .background(Color(0xFFFBFCFE)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "≡",
            fontSize = 40.sp,
            modifier = Modifier.padding(start = 10.dp)
        )
        OutlinedTextField(
            value = currentClassName,
            onValueChange = {
                currentClassName = it
                // Replace onClassNameChange logic with your specific logic here
            },
            label = { Text(text = "Classroom Name") },
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent
            )
        )
        Icon(
            painter = painterResource(id = R.drawable.ic_notifications),
            contentDescription = "Notifications",
            modifier = Modifier
                .size(50.dp)
                .padding(12.dp)
                .clickable {
                    // Replace onNotificationClick logic here
                }
        )
        Icon(
            painter = painterResource(id = R.drawable.ic_profile),
            contentDescription = "Profile",
            modifier = Modifier
                .size(50.dp)
                .padding(10.dp)
                .clickable {
                    // Replace onProfileClick logic here
                }
        )
    }
}

