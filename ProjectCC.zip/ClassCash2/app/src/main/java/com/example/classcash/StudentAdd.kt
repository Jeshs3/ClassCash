package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.*

@Composable
fun AddStudentScreen() {

    val studentNames = remember { mutableStateListOf<String>().apply { repeat(10) { add("") } } }

    // Track how many fields to display, starting with 10
    var visibleInputCount by remember { mutableIntStateOf(10) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFADEBB3)) // Frame color
    ) {
        // Recycled TopScreen component
        TopScreenB()

        Spacer(modifier = Modifier.height(15.dp))

        // Main Container
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFF9FCFE)) // Background color
                .padding(16.dp)
        ) {
            // Header row with "0 students" and icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "0 Students",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    painter = painterResource(id = R.drawable.ic_import),
                    contentDescription = "Download Icon",
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Add Student Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_personadd),
                    contentDescription = "Add Person Icon",
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "Add Student",
                    fontWeight = FontWeight.Medium,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Automatically saved",
                    fontWeight = FontWeight.Light,
                    fontSize = 14.sp
                )
                Icon(
                    painter = painterResource(id = R.drawable.ic_check),
                    contentDescription = "Checkmark Icon",
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Input Fields for Students
            Column(modifier = Modifier.fillMaxWidth()) {
                repeat(10) { index ->
                    StudentInputField(studentNumber = index + 1,
                        onNameChange = { name ->
                           autoSave(index, name)
                        },
                        onRemoveClick = {
                            studentNames.removeAt(index)
                        })
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Save Button and Pagination Arrow
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        //batchSaveStudentNames(studentNames)

                        // Navigate back to the dashboard
                        //navController.navigate("dashboard") {
                        //  popUpTo("students") { inclusive = true }
                        //}
                    },
                    modifier = Modifier
                        .weight(1f)
                        .background(Color.Red)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Save",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Icon(
                    painter = painterResource(id = R.drawable.ic_arrow),
                    contentDescription = "Pagination Arrow",
                    modifier = Modifier.size(24.dp)
                        .clickable {
                            // Load more fields (e.g., show 10 more)
                            visibleInputCount += 10
                            // Expand studentNames list if needed
                            repeat(visibleInputCount - studentNames.size) { studentNames.add("") }
                        }
                )
            }
        }
    }
}

@Composable
fun StudentInputField(studentNumber: Int, onNameChange: (String) -> Unit, onRemoveClick: () -> Unit) {

    var text by remember { mutableStateOf(TextFieldValue("")) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFFBFCFE), shape = RoundedCornerShape(30.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = "$studentNumber.",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier.padding(end = 8.dp)
        )

        BasicTextField(
            value = text,
            onValueChange = {
                text = it                   // Updates the text state
                onNameChange(it.text)       // Calls onNameChange with the updated text
            },
            singleLine = true,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        ) {
            if (text.text.isEmpty()) {
                Text(text = "Input Student Name", color = Color.LightGray)
            }
        }

        Icon(
            painter = painterResource(id = R.drawable.ic_close),
            contentDescription = "Remove Icon",
            modifier = Modifier.size(24.dp)
                .clickable{ onRemoveClick() }

        )
    }
}

