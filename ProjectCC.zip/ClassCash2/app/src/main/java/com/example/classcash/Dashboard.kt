package com.example.classcash



import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.layout.Box
import androidx.navigation.NavController

@Composable
fun DashboardScreen(navController: NavController) {

    //val totalBalance = studentList.sumOf { it.amount ?: 0.0 }

    /*LaunchedEffect(navController.currentBackStackEntryAsState()) {
        // Refresh the screen when navigating back to it
        //onRefresh()
    }*/

    val currentDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

    Column(modifier = Modifier
        .background(Color(0xFFADEBB3))
        .fillMaxSize()
    ) {

        //Top Screen Bar
        TopScreenB()

        // Balance Display
        BalanceBox()

        // Divider
        HorizontalDivider(color = Color.White, thickness = 4.dp)

        // Date and Add Students Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .padding(10.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFFBFCFE))
                    .width(100.dp)
                    .padding(10.dp)
            ) {
                Text(
                    text = currentDate,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Box(modifier = Modifier
                .padding(10.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFFBFCFE))
                .width(100.dp)
                .padding(10.dp)
            ){
                Text(
                    text = "Add Students",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable(onClick = {
                            navController.navigate(Routes.studentadd)
                        })
                        .padding(start = 8.dp)
                )
            }

        }
        Spacer(modifier = Modifier.height(420.dp))
        BottomNavigationBar(navController)
    }
}

@SuppressLint("DefaultLocale")
@Composable
fun BalanceBox() {

    var balance by remember{mutableStateOf(0.0)}
    Box(
        modifier = Modifier
            .padding(12.dp)
            .shadow(
                elevation = 8.dp,        // Adjust shadow elevation
                shape = RoundedCornerShape(10.dp), // Rounded corners
                clip = false             // Whether to clip content to the shape
            )
            .background(Color.White)    // White background
            .width(200.dp)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            Text(
                text = "P ${String.format("%.2f", balance)}",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.Black
            )

            Text(
                text = "Total Cash In",
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                color = Color.Black
            )
        }

    }
}
