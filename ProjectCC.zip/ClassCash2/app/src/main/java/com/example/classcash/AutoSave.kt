package com.example.classcash


import androidx.compose.runtime.mutableStateListOf


val studentNames = mutableStateListOf<String>()

fun autoSave(index: Int, name: String) {
    // Ensure the list has enough elements
    while (studentNames.size <= index) {
        studentNames.add("")  // Add empty names until we reach the desired index
    }
    // Update the name at the given index
    studentNames[index] = name
}