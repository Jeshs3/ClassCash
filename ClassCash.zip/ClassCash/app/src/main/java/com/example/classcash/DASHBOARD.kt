package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.layout.Box as Box1

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController, onRefresh: () -> Unit) {

    val currentBackStackEntry by navController.currentBackStackEntryAsState()

    LaunchedEffect(currentBackStackEntry) {
        if (currentBackStackEntry?.destination?.route == "dashboard") {
            onRefresh()
        }
    }

    var balance by remember { mutableStateOf(0.0) }
    var className by remember { mutableStateOf("")}
    val currentDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

    Column(modifier = Modifier
        .background(Color(0xFFADEBB3))
        .fillMaxSize()
    ) {

        //Top Screen
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp)
                .background(Color(0xFFFBFCFE)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "≡",
                fontSize = 40.sp,
                modifier = Modifier.padding(start = 10.dp)
            )
            OutlinedTextField(
                value = className,
                onValueChange = {className = it},
                label = {
                    Text(text = "Classroom Name")
                },// Handle classroom name change here
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp),
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    containerColor = Color.Transparent,  // Set custom container background color
                    focusedBorderColor = Color.Green,
                    unfocusedBorderColor = Color.Transparent,
                )
            )
            Icon(
                painter = painterResource(id = R.drawable.ic_notifications),
                contentDescription = "Notifications",
                modifier = Modifier
                    .size(50.dp)
                    .padding(12.dp)
            )
            Icon(
                painter = painterResource(id = R.drawable.ic_profile),
                contentDescription = "Profile",
                modifier = Modifier
                    .size(50.dp)
                    .padding(10.dp)
            )
        }

        // Balance Display
        BalanceBox(balance = 0.0)

        // Divider
        Divider(color = Color.White, thickness = 4.dp)

        // Date and Add Students Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box1(
                modifier = Modifier
                    .padding(10.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFFBFCFE))
                    .width(100.dp)
                    .padding(10.dp)
            ) {
                Text(
                    text = currentDate,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Box1(modifier = Modifier
                .padding(10.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFFBFCFE))
                .width(100.dp)
                .padding(10.dp)
            ){
                Text(
                    text = "Add Students",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable(onClick = {
                            navController.navigate("student")
                        })
                        .padding(start = 8.dp)
                )
            }

        }
    }
}

@Composable
fun BalanceBox(balance: Double) {
    Box1(
        modifier = Modifier
            .padding(12.dp)
            .shadow(
                elevation = 8.dp,        // Adjust shadow elevation
                shape = RoundedCornerShape(10.dp), // Rounded corners
                clip = false             // Whether to clip content to the shape
            )
            .background(Color.White)    // White background
            .width(200.dp)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            Text(
                text = "P ${String.format("%.2f", balance)}",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.Black
            )

            Text(
                text = "Total Cash In",
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                color = Color.Black
            )
        }

    }
}

@Composable
fun DashboardScreen(studentList: List<Student>, onAmountClick: (Student) -> Unit) {
    Column {
        // Search Bar
        SearchBar()

        // RecyclerView with student data
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(studentList.take(6)) { student ->
                StudentItem(
                    student = student,
                    onAmountClick = { onAmountClick(student) }
                )
            }
        }
    }
}

@Composable
fun SearchBar() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(Color.Gray.copy(alpha = 0.1f), shape = RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Search Name", color = Color.Gray)
    }
}

@Composable
fun StudentItem(student: Student, monthlyTarget: Double, onAmountClick: () -> Unit) {
    val progressPercentage = (student.amount / monthlyTarget).coerceIn(0.0, 1.0).toFloat()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .background(Color.White, shape = RoundedCornerShape(8.dp))
            .clickable { onAmountClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Progress Circle
        CircularProgressIndicator(
            progress = progressPercentage,
            color = if (student.amount > 0) Color.Red else Color.Gray,
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.width(16.dp))

        // Student Name and Amount
        Column(modifier = Modifier.weight(1f)) {
            Text(text = student.name, fontWeight = FontWeight.Bold)
        }

        // Amount Box
        Box1(
            modifier = Modifier
                .background(Color(0xFFFFA500), shape = RoundedCornerShape(16.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp)
                .clickable { onAmountClick() }
        ) {
            Text(text = "P${student.amount ?: "0.00"}", color = Color.White)
        }
    }
}



@Composable
fun PaymentBox(student: Student, onDismiss: () -> Unit, onEnter: (Double) -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Box1(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFFBFCFE), shape = RoundedCornerShape(10.dp))
                .padding(16.dp)
        ) {
            Column {
                // Student Name and Exit Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = student.name, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Current Date
                Text(text = "Current Date: ${getCurrentDate()}", color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))

                // Input Balance Label and TextField
                Text(text = "Input Balance:")
                TextField(
                    value = "",
                    onValueChange = {},
                    placeholder = { Text("Please enter amount") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, shape = RoundedCornerShape(10.dp))
                        .padding(4.dp)
                        .shadow(2.dp, RoundedCornerShape(10.dp))
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Enter Button
                Button(
                    onClick = { onEnter(amount.toDouble()) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Red, shape = RoundedCornerShape(8.dp))
                ) {
                    Text("Enter", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun NotificationBar(notificationText: String) {
    Box1(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Gray.copy(alpha = 0.8f))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = notificationText, color = Color.White)
    }
}



