package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BudgetViewScreen() {
    // Outer frame with mint green background
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE0F7E8)) // Mint green frame
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp)
        ) {
            // Top recycled screen
            TopScreen()

            Spacer(modifier = Modifier.height(16.dp))

            // Div container for current month, balance, event, expenditures, and pie chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFBFCFE), shape = RoundedCornerShape(8.dp))
                    .padding(16.dp)
                    .shadow(4.dp, shape = RoundedCornerShape(8.dp))
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Current month and year (updatable)
                        Text("October 2024", fontSize = 18.sp, fontWeight = FontWeight.Bold)

                        // Current balance with blue border
                        Text(
                            "Current Balance: $1000",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .border(2.dp, Color.Blue, shape = RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Event and Expenditures text
                    Text("Event: Birthday Party", fontSize = 16.sp)
                    TextField(
                        value = "Expenditures",
                        onValueChange = {},
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Pie chart and breakdown labels (food, fee, other expenses)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Placeholder for Pie Chart
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .background(Color.LightGray, shape = RoundedCornerShape(50.dp))
                        )

                        Column {
                            Text("Food: 0%", fontSize = 14.sp)
                            Text("Fee: 0%", fontSize = 14.sp)
                            Text("Other expenses: 0%", fontSize = 14.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Div container for generated budget display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFBFCFE), shape = RoundedCornerShape(8.dp))
                    .padding(16.dp)
                    .shadow(4.dp, shape = RoundedCornerShape(8.dp))
            ) {
                Column {
                    // Suggested amount with blue border
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Suggested Amount: ")
                        Text(
                            "$500",
                            modifier = Modifier
                                .border(2.dp, Color.Blue, shape = RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            fontSize = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Breakdown table for expense, percentage, and calculated amount
                    Column {
                        ExpenseBreakdownRow("Food", "20%", "$100")
                        ExpenseBreakdownRow("Fee", "30%", "$150")
                        ExpenseBreakdownRow("Other expenses", "50%", "$250")
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Generate icon placeholder on bottom right
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(Color.Blue, shape = RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExpenseBreakdownRow(expenseName: String, percentage: String, amount: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(expenseName, fontSize = 14.sp)
        Text(percentage, fontSize = 14.sp)
        Text(amount, fontSize = 14.sp)
    }
}

// Placeholder for the top screen
@Composable
fun TopScreen() {
    Text("Top Dashboard Screen", fontSize = 20.sp, fontWeight = FontWeight.Bold)
}
