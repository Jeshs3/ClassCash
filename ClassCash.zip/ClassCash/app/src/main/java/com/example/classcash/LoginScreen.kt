@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.classcash

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun LoginScreen(navController: NavController){

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFADEBB3)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = CenterHorizontally
    ) {

        Row (
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(0.dp) // Adjust padding as needed
        ) {
            Image(
                painter = painterResource(id = R.drawable.classlogo),
                contentDescription = "logo",
                modifier = Modifier.size(200.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "ClassCash",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }


        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFFFBFCFE))
                .padding(10.dp)
                .width(300.dp)
                .height(300.dp)
        ){
            Column(
                modifier = Modifier.padding(top = 10.dp),
                horizontalAlignment = CenterHorizontally
            ){
                Text(
                    text = "Sign Up",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.align(CenterHorizontally)
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = {name = it},
                    label = {
                        Text(
                            text = "Name",
                            fontSize = 12.sp
                        )
                    },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color.Green,
                        unfocusedBorderColor = Color.Green,
                        containerColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = {email = it},
                    label = {
                        Text(
                            text = "Email",
                            fontSize = 12.sp
                        )
                    },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color.Green,
                        unfocusedBorderColor = Color.Green,
                        containerColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = {password = it},
                    label = {
                        Text(
                            text = "Password",
                            fontSize = 12.sp
                        )
                    },
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color.Green,
                        unfocusedBorderColor = Color.Green,
                        containerColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }



        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { navController.navigate("dashboard")},
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Red // Replace with your desired color
            ),
            modifier = Modifier.align(CenterHorizontally)
        ) {
            Text(text = "Continue")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Login",
            fontSize = 12.sp,
            fontWeight = FontWeight.Light,
            color = Color.Blue,
            style = TextStyle(
                textDecoration = TextDecoration.Underline // Apply underline
            ),
            modifier = Modifier.clickable { /* Handle login action */ }
        )

        Spacer(modifier = Modifier.height(40.dp))

        Text(
            text = "Sinking Fund Management System",
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraLight,
            modifier = Modifier.align(CenterHorizontally)
        )

        Text(
            text = "All rights reserved 2024",
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraLight,
            modifier = Modifier.align(CenterHorizontally)
        )
    }
}


