package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AddStudentsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFADEBB3)) // Frame color
    ) {
        // Recycled TopScreen component
        TopScreen()

        // Main Container
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFF9FCFE)) // Background color
                .padding(16.dp)
        ) {
            // Header row with "0 students" and icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "0 Students",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    painter = /* provide your download icon painter */,
                    contentDescription = "Download Icon",
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    painter = /* provide your import icon painter */,
                    contentDescription = "Import Icon",
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Add Student Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    painter = /* provide your person-add icon painter */,
                    contentDescription = "Add Person Icon",
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "Add Student",
                    fontWeight = FontWeight.Medium,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(start = 8.dp)
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Automatically saved",
                    fontWeight = FontWeight.Light,
                    fontSize = 14.sp
                )
                Icon(
                    painter = /* provide your checkmark icon painter */,
                    contentDescription = "Checkmark Icon",
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Input Fields for Students
            Column(modifier = Modifier.fillMaxWidth()) {
                repeat(10) { index ->
                    StudentInputField(studentNumber = index + 1)
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Save Button and Pagination Arrow
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { /* Handle save action */ },
                    modifier = Modifier
                        .weight(1f)
                        .background(Color.Red)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Save",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Icon(
                    painter = /* provide your pagination arrow painter */,
                    contentDescription = "Pagination Arrow",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun StudentInputField(studentNumber: Int) {
    var text by remember { mutableStateOf(TextFieldValue("")) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Gray, shape = RoundedCornerShape(30.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = "$studentNumber",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier.padding(end = 8.dp)
        )

        BasicTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        ) {
            if (text.text.isEmpty()) {
                Text(text = "Input Student Name", color = Color.LightGray)
            }
        }

        Icon(
            painter = /* provide your 'x' icon painter */,
            contentDescription = "Remove Icon",
            modifier = Modifier.size(24.dp)
        )
    }
}

