package com.example.classcash

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun FundSettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(Color(0xFFFBFCFE))
    ) {
        // Top screen
        TopScreen()

        // 'Set Collection' label
        Text(
            text = "Set Collection",
            style = MaterialTheme.typography.h5,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        // First container for input fields
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .background(Color(0xFFFBFCFE), shape = RoundedCornerShape(8.dp))
                .shadow(4.dp, RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            // First text field
            TextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("Enter how many months you need to collect") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Second text field
            TextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("How much is the daily fund each student") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Second main container with dropdown and label
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .background(Color(0xFFADEBB3), shape = RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Dropdown for choosing month (labeled by the current year)
                MonthDropdown()

                // 'Setup the date' label
                Text(text = "Setup the date", style = MaterialTheme.typography.subtitle1)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Paginated cards
            PaginatedCards()
        }
    }
}

@Composable
fun MonthDropdown() {
    // This dropdown should display the current year as the label
    var expanded by remember { mutableStateOf(false) }
    var selectedMonth by remember { mutableStateOf("2024") }

    Box {
        Text(
            text = selectedMonth,
            modifier = Modifier.clickable { expanded = true }
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            // List of months
            val months = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
            months.forEach { month ->
                DropdownMenuItem(onClick = {
                    selectedMonth = month
                    expanded = false
                }) {
                    Text(text = month)
                }
            }
        }
    }
}

@Composable
fun PaginatedCards() {
    val months = listOf("January", "February", "March", "April") // replace with actual list
    var pageIndex by remember { mutableStateOf(0) }

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            // Display the selected month and balance
            Text(text = months[pageIndex], modifier = Modifier.weight(1f))
            Text(text = "P0.00", modifier = Modifier.weight(1f)) // Estimated balance
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clickable { /* Open calendar pop-up */ }
            ) {
                // Add custom calendar icon here
            }
        }

        // Pagination controls
        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = { if (pageIndex > 0) pageIndex-- }) {
                Text("<")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = { if (pageIndex < months.size - 1) pageIndex++ }) {
                Text(">")
            }
        }
    }
}
