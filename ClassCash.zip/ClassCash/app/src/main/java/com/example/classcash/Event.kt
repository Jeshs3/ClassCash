package com.example.classcash

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun EventFrame() {
    val currentDate = remember { LocalDate.now() }
    val events = remember { mutableStateOf(mapOf<LocalDate, String>()) } // Placeholder for events

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)
        .background(Color(0xFF98FF98)) // Mint green frame
    ) {
        TopScreen() // Recycled TopScreen from your main dashboard

        // Calendar
        CalendarView(currentDate, events)

        Spacer(modifier = Modifier.height(16.dp))

        // Card Views
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            repeat(3) {
                EventCard()
            }
        }
    }
}

@Composable
fun CalendarView(currentDate: LocalDate, events: MutableState<Map<LocalDate, String>>) {
    // Implement a simple calendar UI here
    // Use events to determine if a date should have a red background
    // This is a placeholder implementation
    val daysInMonth = currentDate.lengthOfMonth()
    val firstDayOfMonth = currentDate.withDayOfMonth(1).dayOfWeek.value
    val calendarDays = (1..daysInMonth).map { day ->
        LocalDate.of(currentDate.year, currentDate.month, day)
    }

    LazyVerticalGrid(
        cells = GridCells.Fixed(7),
        content = {
            items(calendarDays) { date ->
                val isEventDay = events.value.containsKey(date)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(if (isEventDay) Color.Red else Color.Transparent)
                        .border(1.dp, Color.Black)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = date.dayOfMonth.toString())
                }
            }
        }
    )
}

@Composable
fun EventCard() {
    Card(
        modifier = Modifier
            .width(100.dp)
            .padding(8.dp)
            .border(BorderStroke(2.dp, Color.Black), RoundedCornerShape(10.dp)),
        shape = RoundedCornerShape(10.dp),
        elevation = 4.dp
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painter = painterResource(id = R.drawable.circle_add), contentDescription = "Add Event")
            Spacer(modifier = Modifier.width(8.dp))
            TextField(
                value = "",
                onValueChange = { /* Handle notes input */ },
                placeholder = { Text("Add Notes") },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(painter = painterResource(id = R.drawable.generate_budget), contentDescription = "Generate Budget")
        }
    }
}
